<?php
ob_start();
?>
<!DOCTYPE html>
<!-- 
Template Name: Metronic - Responsive Admin Dashboard Template build with Twitter Bootstrap 3.3.2
Version: 3.7.0
Author: KeenThemes
Website: http://www.keenthemes.com/
Contact: support@keenthemes.com
Follow: www.twitter.com/keenthemes
Like: www.facebook.com/keenthemes
Purchase: http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes
License: You must have a valid license purchased only from themeforest(the above link) in order to legally use the theme for your project.
-->
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
<meta charset="utf-8"/>
<?php
$title = "New Subject";
include_once "title.php";
?>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<meta http-equiv="Content-type" content="text/html; charset=utf-8">
<meta content="" name="description"/>
<meta content="" name="author"/>
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css"/>
<link href="../assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/global/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css"/>
<link href="../assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css"/>
<!-- END GLOBAL MANDATORY STYLES -->
<!-- BEGIN PAGE LEVEL STYLES -->
<link rel="stylesheet" type="text/css" href="../assets/global/plugins/select2/select2.css"/>
<link rel="stylesheet" type="text/css" href="../assets/global/plugins/datatables/extensions/Scroller/css/dataTables.scroller.min.css"/>
<link rel="stylesheet" type="text/css" href="../assets/global/plugins/datatables/extensions/ColReorder/css/dataTables.colReorder.min.css"/>
<link rel="stylesheet" type="text/css" href="../assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css"/>
<!-- END PAGE LEVEL STYLES -->
<!-- BEGIN THEME STYLES -->
<link href="../assets/global/css/components.css" id="style_components" rel="stylesheet" type="text/css"/>
<link href="../assets/global/css/plugins.css" rel="stylesheet" type="text/css"/>
<link href="../assets/admin/layout/css/layout.css" rel="stylesheet" type="text/css"/>
<link id="style_color" href="../assets/admin/layout/css/themes/darkblue.css" rel="stylesheet" type="text/css"/>
<link href="../assets/admin/layout/css/custom.css" rel="stylesheet" type="text/css"/>
<!-- END THEME STYLES -->
<link rel="shortcut icon" href="favicon.ico"/>
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<!-- DOC: Apply "page-header-fixed-mobile" and "page-footer-fixed-mobile" class to body element to force fixed header or footer in mobile devices -->
<!-- DOC: Apply "page-sidebar-closed" class to the body and "page-sidebar-menu-closed" class to the sidebar menu element to hide the sidebar by default -->
<!-- DOC: Apply "page-sidebar-hide" class to the body to make the sidebar completely hidden on toggle -->
<!-- DOC: Apply "page-sidebar-closed-hide-logo" class to the body element to make the logo hidden on sidebar toggle -->
<!-- DOC: Apply "page-sidebar-hide" class to body element to completely hide the sidebar on sidebar toggle -->
<!-- DOC: Apply "page-sidebar-fixed" class to have fixed sidebar -->
<!-- DOC: Apply "page-footer-fixed" class to the body element to have fixed footer -->
<!-- DOC: Apply "page-sidebar-reversed" class to put the sidebar on the right side -->
<!-- DOC: Apply "page-full-width" class to the body element to have full width page without the sidebar menu -->
<body class="page-header-fixed page-quick-sidebar-over-content">
<!-- BEGIN HEADER -->
<div class="page-header -i navbar navbar-fixed-top">
	<!-- BEGIN HEADER INNER -->
	<?php
		require_once "header.php";
	?>
	<!-- END HEADER INNER -->
</div>
<!-- END HEADER -->
<div class="clearfix">
</div>
<!-- BEGIN CONTAINER -->
<div class="page-container">
	<!-- BEGIN SIDEBAR -->
	<?php
		$main_title = "Administration";
		$sub_title = "New Subject";
		require_once "sidebar.php";
	?>
	<!-- END SIDEBAR -->
	<!-- BEGIN CONTENT -->
	<div class="page-content-wrapper">
		<div class="page-content">
			<!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->

			<!-- /.modal -->
			<!-- END SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<!-- BEGIN STYLE CUSTOMIZER -->

			<!-- END STYLE CUSTOMIZER -->
			<!-- BEGIN PAGE HEADER-->
			<h3 class="page-title">
			<?php echo $main_title;?> <small><?php echo $sub_title;?></small>
			</h3>
			<div class="page-bar">
				<ul class="page-breadcrumb">
					<li>
						<i class="fa fa-home"></i>
						<a href="#"><?php echo $main_title;?></a>
						<i class="fa fa-angle-right"></i>
					</li>
					<li>
						<a href="#"><?php echo $sub_title;?></a>
					</li>
				</ul>
			</div>
			<!-- END PAGE HEADER-->
			<?php
			// query insert
			if(isset($_POST["submit"])){
									$departments_id = $_POST["departments_id"];
									$Name = $_POST["Name"];
									$Credit = $_POST["Credit"];
									$SemesterID = $_POST["SemesterID"];

									$query = "insert into subjects(DepartmentsID,Name, Credit, SemesterID) values('$departments_id','$Name', '$Credit', '$SemesterID')";
									mysqli_query($GLOBALS['DB'], $query);

									header("Location:new_subject.php?save=1");
									exit();
								}

			// select value for update
			if(isset($_GET['id']))
						{
						$select_update  = "select * from departments where DepartmentsID = '$_GET[id]'";
						$row_update = mysqli_query($GLOBALS['DB'],$select_update)or die(mysqli_error());
						$row_print_update = mysqli_fetch_assoc($row_update);
						}
						
						// update query
						  	if(isset($_POST['update']))
						{

						$Name = $_POST['Name'];
						$id_depertment = $_POST['id_depertment'];
                       $FacultyID = $_POST['FacultyID'];

						$update  = "update departments set `Name` = '$Name', FacultyID = '$FacultyID' where DepartmentsID = '$id_depertment'";
           
						mysqli_query($GLOBALS['DB'],$update)or die(mysqli_error());
						
						header("Location:new_department.php");
				        die();
						}
						
						//delete query
						  	if(isset($_GET['delete_id']))
						{

				

						$delete  = "delete from departments where DepartmentsID = '$_GET[delete_id]'";
           
						mysqli_query($GLOBALS['DB'],$delete)or die(mysqli_error());
				
						header("Location:new_department.php");
				      exit();
						}
			?>
			<!-- BEGIN PAGE CONTENT-->
			<div class="row">
				<div class="col-md-12">
					<!-- BEGIN VALIDATION STATES-->
					<div class="portlet box green">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-home"></i>New Subject
							</div>
							<div class="tools">
								<a href="javascript:;" class="collapse">
								</a>
								<a href="javascript:;" class="reload">
								</a>
							</div>
						</div>
						<div class="portlet-body form">
							<!-- BEGIN FORM-->
							<form action="new_subject.php" method = "post" id="form_sample_2" class="form-horizontal">
								<div class="form-body">
									<div class="alert alert-danger display-hide">
										<button class="close" data-close="alert"></button>
										You have some form errors. Please check below.
									</div>
									<?php
									if(isset($_GET["save"])){
									?>
									<div class="alert alert-success">
										<button class="close" data-close="alert"></button>
										Data Saved Successfully.
									</div>
									<?php
									}
									?>
									<div class="form-group">
										<label class="control-label col-md-3">Faculty <span class="required">
										* </span>
										</label>
										<div class="col-md-4">
											<div class="input-icon right">
												<i class="fa"></i>
												<select name="FacultyID" class="form-control">
													<?php
								$query = "select * from faculties order by FacultyID desc";
								$result = mysqli_query($GLOBALS['DB'], $query);
								$i = 1;
                               echo " <option value=''>Select...</option>";
								while($row = mysqli_fetch_assoc($result)){
									$id = $row["FacultyID"];
									$Name = $row["Name"];

									if($row_print_update['FacultyID'] == $id)
									{

									echo "<option selected value='$id'>$Name</option>";	
									}else
									{
									echo "<option value='$id'>$Name</option>";	
									}
									
								
								}
							?>
						
												</select>
	
											</div>
										</div>
									</div>
									<div class="form-group">
										<label class="control-label col-md-3">Department <span class="required">
										* </span>
										</label>
										<div class="col-md-4">
											<div class="input-icon right">
												<i class="fa"></i>
												<select name="departments_id" class="form-control">
													<?php
								$query = "select * from departments";
								$result = mysqli_query($GLOBALS['DB'], $query);
								$i = 1;
                               echo " <option value=''>Select...</option>";
								while($row = mysqli_fetch_assoc($result)){
									$id = $row["DepartmentsID"];
									$Name = $row["Name"];

									if($row_print_update['FacultyID'] == $id)
									{

									echo "<option selected value='$id'>$Name</option>";	
									}else
									{
									echo "<option value='$id'>$Name</option>";	
									}
									
								
								}
							?>
						
												</select>
	
											</div>
										</div>
									</div>

									<div class="form-group">
										<label class="control-label col-md-3">Name <span class="required">
										* </span>
										</label>
										<div class="col-md-4">
											<div class="input-icon right">
												<i class="fa"></i>
												<input type="text" class="form-control" name="Name" required value="<?php echo $row_print_update['Name']; ?>"/>
											</div>
										</div>
									</div>
							
								<div class="form-group">
										<label class="control-label col-md-3">Credit <span class="required">
										* </span>
										</label>
										<div class="col-md-4">
											<div class="input-icon right">
												<i class="fa"></i>
												<input type="text" class="form-control" name="Credit" required value="<?php echo $row_print_update['Name']; ?>"/>
											</div>
										</div>
									</div>
									
									<div class="form-group">
										<label class="control-label col-md-3">Semester <span class="required">
										* </span>
										</label>
										<div class="col-md-4">
											<div class="input-icon right">
												<i class="fa"></i>
												<select name="SemesterID" class="form-control">
												<?php
													$querySem = "select * from semesters";
													$resultSem = mysqli_query($GLOBALS['DB'], $querySem);
													while($rowSem = mysqli_fetch_assoc($resultSem)){
														$SemesterID = $rowSem["SemesterID"];
														$SemName = $rowSem["Name"];
														echo "<option value='$SemesterID'>$SemName</option>";

													}
													?>
												</select>
											</div>
										</div>
									</div>

								</div>
								<div class="form-actions">
									<div class="row">
										<div class="col-md-offset-3 col-md-9">
										<?php
										if($_GET['id'])
										{
											echo "<button type='submit' name = 'update' class='btn green'>Update</button>";
										}else
										{
										echo "<button type='submit' name = 'submit' class='btn green'>Submit</button>";	
										}
											?>
											<button type="button" class="btn default">Cancel</button>
										</div>
									</div>
								</div>
							</form>
					
							<!-- END FORM-->
						</div>
					</div>
					<!-- END VALIDATION STATES-->
					<!-- BEGIN EXAMPLE TABLE PORTLET-->
					<div class="portlet box green-haze">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-globe"></i>List of Subjects
							</div>
							<div class="tools">
								<a href="javascript:;" class="reload">
								</a>
								<a href="javascript:;" class="remove">
								</a>
							</div>
						</div>
						<div class="portlet-body">
							<table class="table table-striped table-bordered table-hover" id="sample_2">
							<thead>
							<tr>
								<th width = "5%">
									 #
								</th>
								<th>
									 Department
								</th>
								<th>
									 Name
								</th>
								<th>
									 Credit
								</th>
								<th>
									 ID Number
								</th>
								<th>
									 Gender
								</th>
								<th width = "15%">
									 Edit
								</th>
								<th width = "15%">
									 Delete
								</th>
							</tr>
							</thead>
							<tbody>
							<?php
								$query = "select * from students";
								$result = mysqli_query($GLOBALS['DB'], $query);
								$i = 1;
								while($row = mysqli_fetch_assoc($result)){
									$departments_id = $row["departments_id"];
									$FirstName = $row["FirstName"];
									$LastName = $row["LastName"];
									$IDNumber = $row["IDNumber"];
									$Gender = $row["Gender"];
									if($Gender == "M"){
										$Gender = "Male";
									}else{
										$Gender = "Female";
									}


                                $query_department = "select Name from departments where DepartmentsID = '$departments_id'";
						$result_Dept = mysqli_query($GLOBALS['DB'], $query_department);
								$row_Dept = mysqli_fetch_assoc($result_Dept);
                                $Dept_name = $row_Dept['Name'];
									echo "<tr><td>".$i."</td>";
									echo "<td>$Dept_name</td>
											<td>$FirstName</td>
											<td>$LastName</td>
											<td>$IDNumber</td>
											<td>$Gender</td>
									<td><a href='new_department.php?id=$DepartmentsID' class='btn btn-xs purple'>Edit <i class='fa fa-edit'></i></a></td>
									<td><a href='new_department.php?delete_id=$DepartmentsID' class='btn btn-xs red'> Delete<i class='fa fa-times'></i></a></td></tr>";
									$i++;
								}
							?>
							</tbody>
							</table>
						</div>
					</div>
					<!-- END EXAMPLE TABLE PORTLET-->
				</div>
			</div>
			<!-- END PAGE CONTENT-->
		</div>
	</div>
	<!-- END CONTENT -->
	<!-- BEGIN QUICK SIDEBAR -->

	<!-- END QUICK SIDEBAR -->
</div>
<!-- END CONTAINER -->
<!-- BEGIN FOOTER -->
<?php
	require_once "footer.php";
?>
<!-- END FOOTER -->
<!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
<!-- BEGIN CORE PLUGINS -->
<!--[if lt IE 9]>
<script src="../../assets/global/plugins/respond.min.js"></script>
<script src="../../assets/global/plugins/excanvas.min.js"></script> 
<![endif]-->
<script src="../assets/global/plugins/jquery.min.js" type="text/javascript"></script>
<script src="../assets/global/plugins/jquery-migrate.min.js" type="text/javascript"></script>
<!-- IMPORTANT! Load jquery-ui.min.js before bootstrap.min.js to fix bootstrap tooltip conflict with jquery ui tooltip -->
<script src="../assets/global/plugins/jquery-ui/jquery-ui.min.js" type="text/javascript"></script>
<script src="../assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../assets/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
<script src="../assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<script src="../assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
<script src="../assets/global/plugins/jquery.cokie.min.js" type="text/javascript"></script>
<script src="../assets/global/plugins/uniform/jquery.uniform.min.js" type="text/javascript"></script>
<script src="../assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
<!-- END CORE PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<script type="text/javascript" src="../assets/global/plugins/jquery-validation/js/jquery.validate.min.js"></script>
<script type="text/javascript" src="../assets/global/plugins/jquery-validation/js/additional-methods.min.js"></script>
<script type="text/javascript" src="../assets/global/plugins/select2/select2.min.js"></script>
<script type="text/javascript" src="../assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="../assets/global/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js"></script>
<script type="text/javascript" src="../assets/global/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js"></script>
<script type="text/javascript" src="../assets/global/plugins/ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="../assets/global/plugins/bootstrap-markdown/js/bootstrap-markdown.js"></script>
<script type="text/javascript" src="../assets/global/plugins/bootstrap-markdown/lib/markdown.js"></script>
<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<script type="text/javascript" src="../assets/global/plugins/select2/select2.min.js"></script>
<script type="text/javascript" src="../assets/global/plugins/datatables/media/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../assets/global/plugins/datatables/extensions/TableTools/js/dataTables.tableTools.min.js"></script>
<script type="text/javascript" src="../assets/global/plugins/datatables/extensions/ColReorder/js/dataTables.colReorder.min.js"></script>
<script type="text/javascript" src="../assets/global/plugins/datatables/extensions/Scroller/js/dataTables.scroller.min.js"></script>
<script type="text/javascript" src="../assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js"></script>
<!-- END PAGE LEVEL PLUGINS -->
<script src="../assets/global/scripts/metronic.js" type="text/javascript"></script>
<script src="../assets/admin/layout/scripts/layout.js" type="text/javascript"></script>
<script src="../assets/admin/layout/scripts/quick-sidebar.js" type="text/javascript"></script>
<script src="../assets/admin/layout/scripts/demo.js" type="text/javascript"></script>
<script src="../assets/admin/pages/scripts/form-validation.js"></script>
<script src="../assets/admin/pages/scripts/table-advanced.js"></script>
<script>
      jQuery(document).ready(function() {    
         Metronic.init(); // init metronic core components
		Layout.init(); // init current layout
		QuickSidebar.init(); // init quick sidebar
		Demo.init(); // init demo features
		FormValidation.init();
		TableAdvanced.init();
      });
   </script>
<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>