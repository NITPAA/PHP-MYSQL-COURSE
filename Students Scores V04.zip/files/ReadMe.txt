Homework:

1. Work edit, delete of (New Subject, Add Student, Add Student Score).
2. in Add Student Score if total is greather than 55 background be green otherwise red.


please take it serious and bring it on the next friday.