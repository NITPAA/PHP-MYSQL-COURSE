<?php
require_once("db.php");

$student_id = $_POST['student_id'];

$query = "select * from studentsscores,students where students.StudentID = studentsscores.StudentID and IDNumber = '$student_id'";

								$result = mysqli_query($GLOBALS['DB'], $query);
								$i = 1;
								while($row = mysqli_fetch_assoc($result)){
									$StudentID = $row["StudentID"];
									$Year = $row["Year"];
									$SubjectID = $row["SubjectID"];
									$TenPercent1 = $row["TenPercent1"];
									$TenPercent2 = $row["TenPercent2"];
									$TwentyPercent = $row["TwentyPercent"];
									$Final = $row["Final"];
									$Total = $row["Total"];

                                    if($Total < 55){
                                      $print_total = "<td style='background-color:red; color:white;'><b>$Total</b></td>";
                                    }else
                                    {
                                    	 $print_total = "<td>$Total</td>";

                                    }



                                $query_st = "select FirstName, LastName, IDNumber from students where StudentID = '$StudentID'";
						$result_st = mysqli_query($GLOBALS['DB'], $query_st);
								$row_st = mysqli_fetch_assoc($result_st);
                                $st_name = $row_st['FirstName']." ".$row_st["LastName"]."(".$row_st["IDNumber"].")";

                                	$query_sub = "select * from subjects where SubjectID = '$SubjectID'";
						$result_sub = mysqli_query($GLOBALS['DB'], $query_sub);
								$row_sub = mysqli_fetch_assoc($result_sub);
                                $sub_name = $row_sub['Name'];
                                $DepartmentsID = $row_sub['DepartmentsID'];
                                $SemesterID = $row_sub['SemesterID'];

                                $query_department = "select Name,FacultyID from departments where DepartmentsID = '$DepartmentsID'";
								$result_Dept = mysqli_query($GLOBALS['DB'], $query_department);
								$row_Dept = mysqli_fetch_assoc($result_Dept);
                                $Dept_name = $row_Dept['Name'];
                                $FacultyID = $row_Dept['FacultyID'];

                                $query_faulty = "select * from faculties where FacultyID = '$FacultyID'";
						        $result_faculty = mysqli_query($GLOBALS['DB'], $query_faulty);
								$row = mysqli_fetch_assoc($result_faculty);
                                $faculty_name = $row['Name'];

                                $query_semester = "select * from semesters where SemesterID = '$SemesterID'";
						        $result_semester = mysqli_query($GLOBALS['DB'], $query_semester);
								$row = mysqli_fetch_assoc($result_semester);
                                $semester_name = $row['Name'];

									echo "<tr><td>".$i."</td>";
									echo "
									<td>$faculty_name</td>
									<td>$Dept_name</td>
									<td>$st_name</td>
											<td>$Year</td>
											<td>$semester_name</td>
											<td>$sub_name</td>
											<td>$TenPercent1</td>
											<td>$TenPercent2</td>
											<td>$TwentyPercent</td>
											<td>$Final</td>
											$print_total
									</tr>";
									$i++;
								}