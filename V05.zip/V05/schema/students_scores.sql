-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2019 at 10:08 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `students_scores`
--

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `DepartmentsID` int(11) NOT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `FacultyID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`DepartmentsID`, `Name`, `FacultyID`) VALUES
(1, 'Civil', 5),
(2, 'MIS', 2),
(3, 'Melli Economy', 4);

-- --------------------------------------------------------

--
-- Table structure for table `faculties`
--

CREATE TABLE `faculties` (
  `FacultyID` int(11) NOT NULL,
  `Name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faculties`
--

INSERT INTO `faculties` (`FacultyID`, `Name`) VALUES
(1, 'Computer Science'),
(2, 'Computer Science'),
(3, 'Law'),
(4, 'Economic'),
(5, 'Engineering'),
(6, 'Engi1'),
(7, 'Medicine');

-- --------------------------------------------------------

--
-- Table structure for table `semesters`
--

CREATE TABLE `semesters` (
  `SemesterID` int(11) NOT NULL,
  `Name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `semesters`
--

INSERT INTO `semesters` (`SemesterID`, `Name`) VALUES
(1, 'First Semester'),
(2, 'Second Semester');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `departments_id` int(11) NOT NULL,
  `StudentID` int(11) NOT NULL,
  `FirstName` varchar(45) DEFAULT NULL,
  `LastName` varchar(45) DEFAULT NULL,
  `IDNumber` varchar(45) DEFAULT NULL,
  `Gender` enum('F','M') DEFAULT NULL,
  `Phone` varchar(45) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`departments_id`, `StudentID`, `FirstName`, `LastName`, `IDNumber`, `Gender`, `Phone`, `Address`) VALUES
(2, 1, 'M.Zalmai ', 'Rahmani', '20903', 'M', '078554622558', 'ee'),
(3, 2, 'Edris', 'Amini', '555', 'M', '078554622558', 'Kabul');

-- --------------------------------------------------------

--
-- Table structure for table `studentsscores`
--

CREATE TABLE `studentsscores` (
  `StudentScoreID` int(11) NOT NULL,
  `Year` int(11) NOT NULL,
  `TenPercent1` decimal(4,2) DEFAULT NULL,
  `TenPercent2` decimal(4,2) DEFAULT NULL,
  `TwentyPercent` decimal(4,2) DEFAULT NULL,
  `Final` decimal(4,2) DEFAULT NULL,
  `Total` decimal(5,2) DEFAULT NULL,
  `StudentID` int(11) NOT NULL,
  `SubjectID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `studentsscores`
--

INSERT INTO `studentsscores` (`StudentScoreID`, `Year`, `TenPercent1`, `TenPercent2`, `TwentyPercent`, `Final`, `Total`, `StudentID`, `SubjectID`) VALUES
(1, 2009, '10.00', '10.00', '20.00', '60.00', '100.00', 1, 1),
(2, 2018, '5.00', '5.00', '5.00', '30.00', '45.00', 1, 2),
(3, 2018, '8.00', '8.00', '8.00', '48.00', '72.00', 1, 3),
(4, 2018, '10.00', '10.00', '18.00', '55.00', '93.00', 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `SubjectID` int(11) NOT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `Credit` varchar(45) DEFAULT NULL,
  `DepartmentsID` int(11) NOT NULL,
  `SemesterID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`SubjectID`, `Name`, `Credit`, `DepartmentsID`, `SemesterID`) VALUES
(1, 'Math', '3', 1, 2),
(2, 'MYsql', '4', 2, 1),
(3, 'Java', '5', 2, 1),
(4, 'Economy I', '2', 3, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`DepartmentsID`),
  ADD KEY `fk_Departments_Faculties_idx` (`FacultyID`);

--
-- Indexes for table `faculties`
--
ALTER TABLE `faculties`
  ADD PRIMARY KEY (`FacultyID`);

--
-- Indexes for table `semesters`
--
ALTER TABLE `semesters`
  ADD PRIMARY KEY (`SemesterID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`StudentID`);

--
-- Indexes for table `studentsscores`
--
ALTER TABLE `studentsscores`
  ADD PRIMARY KEY (`StudentScoreID`),
  ADD KEY `fk_StudentsScores_Students1_idx` (`StudentID`),
  ADD KEY `fk_StudentsScores_Subjects1_idx` (`SubjectID`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`SubjectID`),
  ADD KEY `fk_Subjects_Departments1_idx` (`DepartmentsID`),
  ADD KEY `fk_Subjects_Semesters1_idx` (`SemesterID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `DepartmentsID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `faculties`
--
ALTER TABLE `faculties`
  MODIFY `FacultyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `semesters`
--
ALTER TABLE `semesters`
  MODIFY `SemesterID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `StudentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `studentsscores`
--
ALTER TABLE `studentsscores`
  MODIFY `StudentScoreID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `SubjectID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `fk_Departments_Faculties` FOREIGN KEY (`FacultyID`) REFERENCES `faculties` (`FacultyID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `studentsscores`
--
ALTER TABLE `studentsscores`
  ADD CONSTRAINT `fk_StudentsScores_Students1` FOREIGN KEY (`StudentID`) REFERENCES `students` (`StudentID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_StudentsScores_Subjects1` FOREIGN KEY (`SubjectID`) REFERENCES `subjects` (`SubjectID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `fk_Subjects_Departments1` FOREIGN KEY (`DepartmentsID`) REFERENCES `departments` (`DepartmentsID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Subjects_Semesters1` FOREIGN KEY (`SemesterID`) REFERENCES `semesters` (`SemesterID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
