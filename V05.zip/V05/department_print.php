<?php
require_once("db.php");

$FacultyID = $_POST['FacultyID'];

$query = "select * from departments where FacultyID = '$FacultyID'";
								$result = mysqli_query($GLOBALS['DB'], $query);

                               echo " <option value=''>Select...</option>";
								while($row = mysqli_fetch_assoc($result)){
									$id = $row["DepartmentsID"];
									$Name = $row["Name"];

									echo "<option value='$id'>$Name</option>";	
									
								}