<?php
require_once("db.php");

$StudentID = $_POST['StudentID'];

$query = "select * from students where StudentID='$StudentID'";
								$result = mysqli_query($GLOBALS['DB'], $query);
                          
								$row = mysqli_fetch_assoc($result);
								$departments_id = $row["departments_id"];

								$query = "select * from subjects where DepartmentsID = '$departments_id' ";
								$result = mysqli_query($GLOBALS['DB'], $query);
								$i = 1;
                               echo " <option value=''>Select...</option>";
								while($row = mysqli_fetch_assoc($result)){
									$id = $row["SubjectID"];
									$Name = $row["Name"];

									if($row_print_update['FacultyID'] == $id)
									{

									echo "<option selected value='$id'>$Name</option>";	
									}else
									{
									echo "<option value='$id'>$Name</option>";	
									}
									
								
								}